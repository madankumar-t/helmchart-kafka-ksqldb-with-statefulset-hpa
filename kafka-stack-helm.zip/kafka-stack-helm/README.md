# Kafka (KRaft) + Schema Registry + Kafka Connect + ksqlDB — Helm charts

This repo contains **four separate Helm charts**:
- `charts/kafka` — Kafka in **KRaft** mode (combined controller+broker, StatefulSet)
- `charts/schema-registry`
- `charts/kafka-connect`
- `charts/ksqldb`

## Prereqs
- kubectl, Helm
- EKS cluster **dcli-rlr-eks-cluster**
- Namespace **rlr**
- StorageClass `gp3` (or edit `values.yaml`)

## Deploy (order matters)
```bash
aws eks update-kubeconfig --name dcli-rlr-eks-cluster --region <your-region>
kubectl create namespace rlr || true

# 1) Kafka
helm install kafka ./charts/kafka -n rlr
kubectl -n rlr rollout status statefulset/kafka

# 2) Schema Registry
helm install schema-registry ./charts/schema-registry -n rlr

# 3) Kafka Connect
helm install kafka-connect ./charts/kafka-connect -n rlr

# 4) ksqlDB
helm install ksqldb ./charts/ksqldb -n rlr

kubectl -n rlr get pods,svc
```

## Images
These charts default to your public ECR images:
- `public.ecr.aws/q9v7p8s3/localdev/confluentinc/cp-kafka`
- `public.ecr.aws/q9v7p8s3/localdev/confluentinc/cp-schema-registry`
- `public.ecr.aws/q9v7p8s3/localdev/confluentinc/cp-kafka-connect`
- `public.ecr.aws/q9v7p8s3/localdev/confluentinc/ksqldb-server`

## Notes
- The Kafka chart runs pods in **combined** mode (controller+broker), with per-pod `node.id` derived from the StatefulSet ordinal.
- If you need external access or security (SASL/SCRAM, TLS), adjust `values.yaml` and add env/secret mounts as needed.
