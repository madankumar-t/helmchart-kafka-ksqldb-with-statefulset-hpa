# Kafka Helm Chart

- StatefulSet with PVC via `volumeClaimTemplates`
- Service exposing ports 9092, 29092, 9093
- TCP probes on 29092
- Optional HPA (CPU-based)

Install:
```bash
helm install kafka ./kafka-chart -n rlr
```
