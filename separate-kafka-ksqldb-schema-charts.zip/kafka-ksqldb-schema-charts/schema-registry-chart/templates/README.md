# Schema Registry Helm Chart

- Deployment + Service on port 8081
- Optional PVC and HPA
- Optional logging sidecar (disabled by default)

Install:
```bash
helm install schema-registry ./schema-registry-chart -n rlr
```
